﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


Requirements
------------

| It requires TYPO3 6.2 and PHP 5.3.
| Also it uses cURL librabry, then you should have installed the libcurl package (>=7.10.5). 


