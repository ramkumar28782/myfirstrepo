﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt

Questions and feedback
---------------------
If you have questions, feedback or suggestions you can send me a mail.

`REST client on forge.typo3.org <https://forge.typo3.org/projects/extension-restclient>`_. 



