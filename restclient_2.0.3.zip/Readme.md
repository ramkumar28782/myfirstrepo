# Extension ``restclient`` 

This extension basically provides a class library for sending HTTP requests and receiving HTTP responses from a RESTful API resource.
You can set many options by using Typo3-Backend, or even the HttpClient* setter.
The CRUD operations GET, POST, PUT, DELETE are supported. 
The HttpClient class is cURL library based.

## Documentation

You can find complete documentation here[1].

[1]: https://docs.typo3.org/typo3cms/extensions/restclient/

## Feedback for composer mode

I would appreciate it if you give me some feedback.
If you download and install this extension in composer mode, i please you to star my project.
